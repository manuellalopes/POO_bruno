package br.com.classes.interfaces;

public interface Isaldo {
	
	void sacar(int valor);
	
	void depositar(int valor);

}
