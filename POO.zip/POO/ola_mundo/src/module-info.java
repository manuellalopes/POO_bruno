/**
 * 
 */
/**
 * @author suporte
 *
 */
module ola_mundo {
}